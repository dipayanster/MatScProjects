#!/bin/bash
# Recommended PAW potentials (PBE)
cat $POTCAR_LIB/Au_pv/POTCAR \
    $POTCAR_LIB/Hg/POTCAR \
    $POTCAR_LIB/O/POTCAR > POTCAR
